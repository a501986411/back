### 开发环境部署项目 文档

- 目录结构准备
> /data/src   项目源码目录
>
> /data/logs/nginx nginx 日志目录
- pull相应的项目源码到 /data/src目录下
- 运行下面的命令

> ./build.sh

- 需要配置hosts
  127.0.0.1 ad-apidev.xmp.ai web-apidev.xmp.ai


---
### 待实现功能

- 自动拉取代码
- 自动配置hosts

