### php 扩展配置文件(.ini)存放位置
``` 
; Enable swoole extension module
extension=swoole.so
```
