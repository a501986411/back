#!/bin/bash
echo "start exec start.sh ..."
/usr/sbin/php-fpm
