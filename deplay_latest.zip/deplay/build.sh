#!/bin/bash
cd /data/src/deplay
docker-compose up --build -d --remove-orphans